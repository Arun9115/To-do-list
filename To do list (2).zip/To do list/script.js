document.getElementById('add-task').addEventListener('click', function() {
    let taskText = document.getElementById('new-task').value;
    if (taskText !== '') {
        addTask(taskText);
        document.getElementById('new-task').value = '';  // Clear input field
    }
});

function addTask(text) {
    let taskList = document.getElementById('task-list');
    let taskItem = document.createElement('li');
    
    let taskText = document.createElement('span');
    taskText.textContent = text;
    
    let deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', function() {
        taskList.removeChild(taskItem);
    });
    
    taskItem.appendChild(taskText);
    taskItem.appendChild(deleteButton);
    taskList.appendChild(taskItem);
}
